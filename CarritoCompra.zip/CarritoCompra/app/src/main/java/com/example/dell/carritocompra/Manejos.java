package com.example.dell.carritocompra;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class Manejos extends BaseAdapter {
    Context con;
    String [] poem;
    int [] imagenes;
    LayoutInflater inflater;

    public Manejos(Context con , String [] poem, int [] imagenes){
     this.con = con;
     this.poem = poem;
     this.imagenes = imagenes;
    }


    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ImageView img;
        TextView lista;

        inflater=(LayoutInflater) con.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View ver = inflater.inflate(R.layout.enlaclista,viewGroup,false);

        img = (ImageView) ver.findViewById(R.id.imageView);
        lista = (TextView) ver.findViewById(R.id.textView2);

        img.setImageResource(imagenes[i]);
        lista.setText(poem[i]);
        return null;
    }
}
