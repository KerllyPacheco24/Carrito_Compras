package com.example.dell.carritocompra;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class Listas extends AppCompatActivity {

    Manejos op;

    String [] listaInsumo = new String []{
            "Cirugía",
            "Diagnostico",
            "Instrumental",
            "Insumos"


    };


    int [] po = {
            R.drawable.cirugia,
            R.drawable.diagnostico,
            R.drawable.instrumental,
            R.drawable.insumos
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listas);

        final ListView lv = (ListView) findViewById(R.id.listView);

        op = new Manejos(this,listaInsumo,po);
        lv.setAdapter(op);


        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long l) {
                Toast.makeText(getApplicationContext(),"Usted a presionado la imagen"+i,Toast.LENGTH_LONG).show();
            }
        });
    }
}
